from flask import Flask, render_template, request, redirect, url_for, g
import sqlite3
import os

app = Flask(__name__)
DATABASE = 'hostel.db'

def get_db():
    db = getattr(g, '_database', None)
    if db is None:
        db = g._database = sqlite3.connect(DATABASE)
        db.row_factory = sqlite3.Row
        db.execute("PRAGMA foreign_keys = ON")
    return db

@app.teardown_appcontext
def close_connection(exception):
    db = getattr(g, '_database', None)
    if db is not None:
        db.close()

def init_db():
    with app.app_context():
        db = get_db()
        with open('schema.sql', 'r') as f:
            db.executescript(f.read())
        if not db.execute("SELECT * FROM blocks").fetchone():
            db.execute("INSERT INTO blocks (block_name, total_rooms) VALUES ('Block A', 10)")
            db.execute("INSERT INTO blocks (block_name, total_rooms) VALUES ('Block B', 10)")
            db.execute("INSERT INTO rooms (block_id, room_number, room_type, bed_count, status) VALUES (1, '101', 'Double', 2, 'Vacant')")
            db.execute("INSERT INTO rooms (block_id, room_number, room_type, bed_count, status) VALUES (1, '102', 'Single', 1, 'Vacant')")
            db.execute("INSERT INTO rooms (block_id, room_number, room_type, bed_count, status) VALUES (2, '201', 'Dormitory', 4, 'Vacant')")
            db.commit()

@app.route('/')
def index():
    db = get_db()
    total_students = db.execute("SELECT COUNT(*) FROM students").fetchone()[0]
    total_rooms = db.execute("SELECT COUNT(*) FROM rooms").fetchone()[0]
    vacant_rooms = db.execute("SELECT COUNT(*) FROM rooms WHERE status='Vacant'").fetchone()[0]
    mess_dues = db.execute("SELECT SUM(mess_fee + extra_charges) FROM mess_bills WHERE payment_status='Due'").fetchone()[0] or 0
    elec_dues = db.execute("SELECT SUM(amount) FROM electricity_bills WHERE payment_status='Due'").fetchone()[0] or 0
    total_dues = mess_dues + elec_dues
    return render_template('index.html', students=total_students, rooms=total_rooms, vacant=vacant_rooms, dues=total_dues)

@app.route('/students', methods=['GET', 'POST'])
def manage_students():
    db = get_db()
    if request.method == 'POST':
        name = request.form['name']
        email = request.form['email']
        phone = request.form['phone']
        room_id = request.form.get('room_id')
        
        try:
            db.execute("INSERT INTO students (name, email, phone, room_id) VALUES (?, ?, ?, ?)", 
                       (name, email, phone, room_id if room_id else None))
            if room_id:
                db.execute("UPDATE rooms SET status='Occupied' WHERE room_id=?", (room_id,))
            db.commit()
        except sqlite3.IntegrityError:
            pass
        return redirect(url_for('manage_students'))
    
    students = db.execute("SELECT s.*, r.room_number FROM students s LEFT JOIN rooms r ON s.room_id = r.room_id").fetchall()
    rooms = db.execute("SELECT * FROM rooms WHERE status='Vacant'").fetchall()
    return render_template('students.html', students=students, rooms=rooms)

@app.route('/students/delete/<int:student_id>', methods=['POST'])
def delete_student(student_id):
    db = get_db()
    student = db.execute("SELECT room_id FROM students WHERE student_id=?", (student_id,)).fetchone()
    if student and student['room_id']:
        db.execute("UPDATE rooms SET status='Vacant' WHERE room_id=?", (student['room_id'],))
    db.execute("DELETE FROM students WHERE student_id=?", (student_id,))
    db.commit()
    return redirect(url_for('manage_students'))

@app.route('/rooms', methods=['GET', 'POST'])
def manage_rooms():
    db = get_db()
    if request.method == 'POST':
        block_select = request.form.get('block_select')
        block_manual = request.form.get('block_manual', '').strip()
        
        if block_manual:
            b_row = db.execute("SELECT block_id FROM blocks WHERE block_name = ?", (block_manual,)).fetchone()
            if b_row:
                block_id = b_row['block_id']
            else:
                cur = db.execute("INSERT INTO blocks (block_name, total_rooms) VALUES (?, 10)", (block_manual,))
                block_id = cur.lastrowid
        else:
            block_id = block_select

        room_number = request.form['room_number']
        room_type = request.form['room_type']
        bed_count = int(request.form['bed_count'])
        
        if block_id:
            db.execute("INSERT INTO rooms (block_id, room_number, room_type, bed_count, status) VALUES (?, ?, ?, ?, 'Vacant')",
                       (block_id, room_number, room_type, bed_count))
            db.commit()
        return redirect(url_for('manage_rooms'))

    rooms = db.execute("SELECT r.*, b.block_name FROM rooms r JOIN blocks b ON r.block_id = b.block_id").fetchall()
    blocks = db.execute("SELECT * FROM blocks").fetchall()
    return render_template('rooms.html', rooms=rooms, blocks=blocks)

@app.route('/rooms/edit/<int:room_id>', methods=['GET', 'POST'])
def edit_room(room_id):
    db = get_db()
    if request.method == 'POST':
        room_number = request.form['room_number']
        room_type = request.form['room_type']
        bed_count = int(request.form['bed_count'])
        status = request.form['status']
        db.execute("UPDATE rooms SET room_number=?, room_type=?, bed_count=?, status=? WHERE room_id=?",
                   (room_number, room_type, bed_count, status, room_id))
        db.commit()
        return redirect(url_for('manage_rooms'))
    
    room = db.execute("SELECT r.*, b.block_name FROM rooms r JOIN blocks b ON r.block_id = b.block_id WHERE r.room_id=?", (room_id,)).fetchone()
    blocks = db.execute("SELECT * FROM blocks").fetchall()
    return render_template('edit_room.html', room=room, blocks=blocks)

@app.route('/rooms/delete/<int:room_id>', methods=['POST'])
def delete_room(room_id):
    db = get_db()
    db.execute("UPDATE students SET room_id=NULL WHERE room_id=?", (room_id,))
    db.execute("DELETE FROM rooms WHERE room_id=?", (room_id,))
    db.commit()
    return redirect(url_for('manage_rooms'))

@app.route('/mess', methods=['GET', 'POST'])
def manage_mess():
    db = get_db()
    if request.method == 'POST':
        student_id = request.form.get('student_id')
        student_manual = request.form.get('student_manual', '').strip()
        if student_manual:
            s_row = db.execute("SELECT student_id FROM students WHERE name = ?", (student_manual,)).fetchone()
            if s_row:
                student_id = s_row['student_id']
            else:
                cur = db.execute("INSERT INTO students (name, email, phone) VALUES (?, ?, ?)", 
                                 (student_manual, f"{student_manual.lower().replace(' ', '')}@hostel.com", "9999999999"))
                student_id = cur.lastrowid

        month_select = request.form.get('month_select')
        month_manual = request.form.get('month_manual', '').strip()
        month = month_manual if month_manual else month_select

        extra = float(request.form['extra_charges'] or 0)
        status = request.form['payment_status']
        
        if student_id and month:
            db.execute("INSERT INTO mess_bills (student_id, month, extra_charges, payment_status) VALUES (?, ?, ?, ?)", 
                       (student_id, month, extra, status))
            db.commit()
        return redirect(url_for('manage_mess'))
    
    bills = db.execute("SELECT m.*, s.name FROM mess_bills m JOIN students s ON m.student_id = s.student_id").fetchall()
    students = db.execute("SELECT * FROM students").fetchall()
    months = ["January", "February", "March", "April", "May", "June", "July", "August", "September", "October", "November", "December"]
    return render_template('mess.html', bills=bills, students=students, months=months)

@app.route('/electricity/delete/<int:e_bill_id>', methods=['POST'])
def delete_electricity(e_bill_id):
    db = get_db()
    db.execute('DELETE FROM electricity_bills WHERE e_bill_id=?', (e_bill_id,))
    db.commit()
    db.close()
    return redirect(url_for('manage_electricity'))

@app.route('/electricity', methods=['GET', 'POST'])
def manage_electricity():
    db = get_db()
    if request.method == 'POST':
        room_id = request.form.get('room_id')
        month_select = request.form.get('month_select')
        month_manual = request.form.get('month_manual', '').strip()
        month = month_manual if month_manual else month_select

        units = float(request.form['units_consumed'] or 0)
        amount = units * 7.5 
        status = request.form['payment_status']
        
        if room_id and month:
            db.execute("INSERT INTO electricity_bills (room_id, month, units_consumed, amount, payment_status) VALUES (?, ?, ?, ?, ?)",
                       (room_id, month, units, amount, status))
            db.commit()
        return redirect(url_for('manage_electricity'))

    e_bills = db.execute("SELECT eb.*, r.room_number, b.block_name FROM electricity_bills eb JOIN rooms r ON eb.room_id = r.room_id JOIN blocks b ON r.block_id = b.block_id").fetchall()
    rooms = db.execute("SELECT r.*, b.block_name FROM rooms r JOIN blocks b ON r.block_id = b.block_id").fetchall()
    months = ["January", "February", "March", "April", "May", "June", "July", "August", "September", "October", "November", "December"]
    return render_template('electricity.html', e_bills=e_bills, rooms=rooms, months=months)

@app.route('/reports')
def reports():
    db = get_db()
    total_students = db.execute("SELECT COUNT(*) FROM students").fetchone()[0]
    total_rooms = db.execute("SELECT COUNT(*) FROM rooms").fetchone()[0]
    occupied_rooms = db.execute("SELECT COUNT(*) FROM rooms WHERE status='Occupied'").fetchone()[0]
    vacant_rooms = db.execute("SELECT COUNT(*) FROM rooms WHERE status='Vacant'").fetchone()[0]
    
    mess_collection = db.execute("SELECT SUM(mess_fee + extra_charges) FROM mess_bills WHERE payment_status='Paid'").fetchone()[0] or 0
    elec_collection = db.execute("SELECT SUM(amount) FROM electricity_bills WHERE payment_status='Paid'").fetchone()[0] or 0
    total_collection = mess_collection + elec_collection

    return render_template('reports.html', 
                           total_students=total_students, 
                           total_rooms=total_rooms, 
                           occupied_rooms=occupied_rooms, 
                           vacant_rooms=vacant_rooms, 
                           total_collection=total_collection)

if __name__ == '__main__':
    if not os.path.exists(DATABASE):
        init_db()
    else:
        init_db()
    app.run(debug=True, port=5000)
