# Hostel Room Allocation & Mess Management System (HostelHub)

An enhanced full-stack web application built using Python (Flask), SQLite, HTML, CSS, and JavaScript.

## Features Included
1. **Editable Hostel Rooms Overview**: Fully interactive table with **Edit** and **Delete** actions for every room, complete with select vs manual block entry.
2. **12 Months Select + Manual Input**: Full dropdown for all 12 calendar months with options to type custom month labels in Mess and Electricity modules.
3. **Select + Manual Student/Block Support**: Dynamic forms letting you select existing items or type new ones.
4. **Dedicated Electricity Utility Module**: Track monthly power consumption per room.
5. **Collection Reports**: Real-time collection reports and occupancy rate analytics.
