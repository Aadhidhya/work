CREATE TABLE IF NOT EXISTS blocks (
    block_id INTEGER PRIMARY KEY AUTOINCREMENT,
    block_name TEXT NOT NULL,
    total_rooms INTEGER NOT NULL
);

CREATE TABLE IF NOT EXISTS rooms (
    room_id INTEGER PRIMARY KEY AUTOINCREMENT,
    block_id INTEGER,
    room_number TEXT NOT NULL,
    room_type TEXT NOT NULL, 
    bed_count INTEGER NOT NULL,
    status TEXT DEFAULT 'Vacant', 
    FOREIGN KEY (block_id) REFERENCES blocks(block_id) ON DELETE CASCADE
);

CREATE TABLE IF NOT EXISTS students (
    student_id INTEGER PRIMARY KEY AUTOINCREMENT,
    name TEXT NOT NULL,
    email TEXT UNIQUE NOT NULL,
    phone TEXT NOT NULL,
    room_id INTEGER,
    status TEXT DEFAULT 'Active',
    FOREIGN KEY (room_id) REFERENCES rooms(room_id) ON DELETE SET NULL
);

CREATE TABLE IF NOT EXISTS mess_bills (
    bill_id INTEGER PRIMARY KEY AUTOINCREMENT,
    student_id INTEGER,
    month TEXT NOT NULL,
    mess_fee REAL DEFAULT 2500.0,
    extra_charges REAL DEFAULT 0.0,
    payment_status TEXT DEFAULT 'Due',
    FOREIGN KEY (student_id) REFERENCES students(student_id) ON DELETE CASCADE
);

CREATE TABLE IF NOT EXISTS electricity_bills (
    e_bill_id INTEGER PRIMARY KEY AUTOINCREMENT,
    room_id INTEGER,
    month TEXT NOT NULL,
    units_consumed REAL DEFAULT 0.0,
    amount REAL DEFAULT 300.0,
    payment_status TEXT DEFAULT 'Due',
    FOREIGN KEY (room_id) REFERENCES rooms(room_id) ON DELETE CASCADE
);
